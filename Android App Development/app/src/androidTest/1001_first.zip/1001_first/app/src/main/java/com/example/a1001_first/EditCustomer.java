package com.example.a1001_first;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class EditCustomer extends AppCompatActivity {
    EditText etName , etEMail , etPassword , etConfirmPassword ;
    Button btnCancel , btnEdit ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_customer);


        etName = findViewById(R.id.editCustomer_etName);
        etEMail = findViewById(R.id.editCustomer_etEMail);
        etPassword = findViewById(R.id.editCustomer_etPassword) ;
        etConfirmPassword = findViewById(R.id.editCustomer_etConfirmPassword);

        btnCancel = findViewById(R.id.editCustomer_CANCEL) ;
        btnEdit = findViewById(R.id.editCustomer_Edit) ;

        ButtonsClick buttonsClick = new ButtonsClick();
        btnEdit.setOnClickListener(buttonsClick);
        btnCancel.setOnClickListener(buttonsClick);
    }

    ActivityResultLauncher<Intent> launcher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
                @Override
                public void onActivityResult(ActivityResult result) {
                    Intent intent = result.getData();

                }
            }
    );




    class ButtonsClick implements View.OnClickListener {
        public void onClick(View v) {

            if (v.getId() == btnEdit.getId()) {
                if (etPassword.getText().toString().equals(etConfirmPassword.getText().toString())) {
                    //deal with edit shit


                }
                if (v.getId() == btnCancel.getId()) {
                    finish();
                }

            }


        }
}
}