package com.example.a1001_first;

public enum UserType {
    ADMIN, CUSTOMER, COMPANY

}
