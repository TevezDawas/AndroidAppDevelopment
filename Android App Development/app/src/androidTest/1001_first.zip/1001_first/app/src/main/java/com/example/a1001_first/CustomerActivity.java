package com.example.a1001_first;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class CustomerActivity extends AppCompatActivity {

    Button btnMyCoupon;
    Button btnEdit;
    Button btnDelete;
    TextView Name;
    TextInputLayout fullNameLabel;
    TextInputLayout Email;
    TextInputEditText FullNameText;
    TextInputEditText EmailText;
    TextView logout;
    Button btnChangePass;
    Button getBtnCoupon;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer);
        btnChangePass = findViewById(R.id.changepasswordid);
        logout = findViewById(R.id.logoutid);
        btnMyCoupon = findViewById(R.id.mycoupons);
        getBtnCoupon = findViewById(R.id.getcoupons);
        btnEdit = findViewById(R.id.main_editbtn);
        btnDelete = findViewById(R.id.main_deletebtn);
        Name = findViewById(R.id.full_name);
        fullNameLabel = findViewById(R.id.fullnamelabel);
        Email = findViewById(R.id.emaillabel);
        FullNameText = findViewById(R.id.fullnametext);
        EmailText = findViewById(R.id.emailtext);

        btnMyCoupon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CustomerActivity.this, Customer_Buy_Coupons.class));
            }
        });

        getBtnCoupon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CustomerActivity.this, ListCustomer_Coupons.class));
            }
        });



    }


}