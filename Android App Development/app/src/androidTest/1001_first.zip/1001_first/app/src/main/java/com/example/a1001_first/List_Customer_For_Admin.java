package com.example.a1001_first;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class List_Customer_For_Admin extends AppCompatActivity {

    ArrayList<String> names = new ArrayList<>();

    DB_Manager db = DB_Manager.getInstance(this);

    ListView lvNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_customer_for_admin);

          lvNames = findViewById(R.id.main_lvNames);

          for (Customer name : db.getAACustomers()) {
          names.add(name.getFIRST_NAME() +' '+name.getLAST_NAME());
        }

        ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, names);
        lvNames.setAdapter(arrayAdapter);

        lvNames.setOnItemClickListener((adapterView, view, i, l) -> startActivity(new Intent(List_Customer_For_Admin.this, CustomerFromAdminActivity.class)));

    }

}