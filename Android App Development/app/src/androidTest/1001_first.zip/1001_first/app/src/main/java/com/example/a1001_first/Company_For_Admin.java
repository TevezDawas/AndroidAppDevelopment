package com.example.a1001_first;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class Company_For_Admin extends AppCompatActivity {

    Button btnManageCoupon;
    Button btnEdit;
    Button btnDelete;
    ImageView profileImage;
    TextView Name;
    TextInputLayout CompanyNameLabel;
    TextInputLayout Email;
    TextInputEditText companyNameText;
    TextInputEditText EmailText;

    ImageView goBack;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_for_admin);
        profileImage = findViewById(R.id.profile_background);
        goBack = findViewById(R.id.goback);
        btnManageCoupon = findViewById(R.id.managecouponid);
        btnEdit = findViewById(R.id.main_editbtn);
        btnDelete = findViewById(R.id.main_deletebtn);
        Name = findViewById(R.id.company_name);
        CompanyNameLabel = findViewById(R.id.nameLabelid);
        Email = findViewById(R.id.emaillabelid);
        companyNameText = findViewById(R.id.companytext);
        EmailText = findViewById(R.id.emailtextid);



        btnManageCoupon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Company_For_Admin.this, List_Company_For_Admin.class));
            }
        });
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }


}