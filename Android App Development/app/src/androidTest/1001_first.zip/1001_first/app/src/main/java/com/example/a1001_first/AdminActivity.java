package com.example.a1001_first;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AdminActivity extends AppCompatActivity {

    Button manageCompanies, manageCustomers ,addCustomer,addCompany;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        manageCustomers = findViewById(R.id.Admin_manageCustomersBTN);
        manageCompanies = findViewById(R.id.Admin_manageCompaniesBTN);
        addCustomer = findViewById(R.id.adminActivity_btnAddCustomer);
        addCompany = findViewById(R.id.adminActivity_btnAddCompany);

     ButtonsClick buttonsClick = new ButtonsClick();
        manageCustomers.setOnClickListener(buttonsClick);
        manageCompanies.setOnClickListener(buttonsClick);
        addCustomer.setOnClickListener(buttonsClick);
        addCompany.setOnClickListener(buttonsClick);
    }

    ActivityResultLauncher<Intent> launcher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
                @Override
                public void onActivityResult(ActivityResult result) {
                    Intent intent = result.getData();

                }
            }
    );

    private void OpenMangeCustomerActivity() {
        Intent intent = new Intent(AdminActivity.this, List_Customer_For_Admin.class);
        intent.putExtra("requestCode", 4);
        launcher.launch(intent);
    }
    private void OpenMangeCompanyActivity() {
        Intent intent = new Intent(AdminActivity.this, AddNewCompany.class);
        intent.putExtra("requestCode", 4);
        launcher.launch(intent);
    }
    private void OpenADDCompanyActivity() {
        Intent intent = new Intent(AdminActivity.this, AddNewCompany.class);
        intent.putExtra("requestCode", 4);
        launcher.launch(intent);
    }
    private void OpenADDCustomerActivity() {
        Intent intent = new Intent(AdminActivity.this, AddNewCustomer.class);
        intent.putExtra("requestCode", 4);
        launcher.launch(intent);
    }

    class ButtonsClick implements View.OnClickListener {
        public void onClick(View v) {


            if (v.getId() == manageCustomers.getId()) {
                OpenMangeCustomerActivity();
            }
            if (v.getId() == manageCompanies.getId()) {
                OpenMangeCompanyActivity();
            }
            if (v.getId() == addCustomer.getId()) {
                OpenADDCustomerActivity();
            }
            if (v.getId() == addCompany.getId()) {
                OpenADDCompanyActivity();
            }
        }
    }
}