package com.example.a1001_first;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Home extends AppCompatActivity {

    TextView welcomeText, textUsername,foodName,electName,restName,vacationName,textTrending;
    ImageView menu,searchIcon,FoodIcon,ElectIcon,RestIcon,VacationIcon,homeIcon,profileIcon;
    EditText searchText;
    LinearLayout Food,Elect,Rest,Vacation;
    BottomNavigationView nav;
   View navView;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        welcomeText = findViewById(R.id.textWelcome);
        textUsername = findViewById(R.id.textUserName);
        foodName = findViewById(R.id.electName);
        electName = findViewById(R.id.electName);
        restName = findViewById(R.id.restName);
        vacationName = findViewById(R.id.vacationName);
        textTrending = findViewById(R.id.textTrending);
        menu = findViewById(R.id.imageMenu);
        searchIcon = findViewById(R.id.searchIcon);
        FoodIcon = findViewById(R.id.foodImage);
        ElectIcon = findViewById(R.id.electImage);
        RestIcon = findViewById(R.id.restImage);
        VacationIcon = findViewById(R.id.vacationImage);
        searchText = findViewById(R.id.searchText);
        Food = findViewById(R.id.layoutFood);
        Elect = findViewById(R.id.layoutElectricity);
        Rest = findViewById(R.id.layoutRest);
        Vacation = findViewById(R.id.layoutVacation);
        nav = findViewById(R.id.bottomNavigationView);
        navView = findViewById(R.id.viewDivider);

    }
}