package com.example.a1001_first;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ListCustomer_Coupons extends AppCompatActivity {
    ListView listview;
    ImageView goBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_last_customer_coupons);
        goBack = findViewById(R.id.goback);
        listview  = findViewById(R.id.listviewId);
        ArrayList<String> arrayList = getList();
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(ListCustomer_Coupons.this, android.R.layout.simple_list_item_multiple_choice,arrayList);
        listview.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        listview.setAdapter(arrayAdapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String items = (String)adapterView.getItemAtPosition(i);
                Toast.makeText(ListCustomer_Coupons.this,"Get an "+items,Toast.LENGTH_SHORT).show();
            }
        });
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


    }

    private ArrayList<String> getList(){
        ArrayList<String> arrayList = new ArrayList<>();
        for(int i=1;i<=10;i++){
            arrayList.add("item " + i);
        }
        return arrayList;

    }
}

