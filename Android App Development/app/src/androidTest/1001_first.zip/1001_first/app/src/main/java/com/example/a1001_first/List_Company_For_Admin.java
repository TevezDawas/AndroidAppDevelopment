package com.example.a1001_first;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;

public class List_Company_For_Admin extends AppCompatActivity {

    ListView listview;
    ImageView goBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_buy_coupons);
        goBack = findViewById(R.id.goback);
        listview  = findViewById(R.id.listviewId);
        ArrayList<String> arrayList = getList();
        ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, arrayList);
        listview.setAdapter(arrayAdapter);

        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


    }

    private ArrayList<String> getList(){
        ArrayList<String> arrayList = new ArrayList<>();
        for(int i=1;i<=10;i++){
            arrayList.add("item " + i);
        }
        return arrayList;

    }
}