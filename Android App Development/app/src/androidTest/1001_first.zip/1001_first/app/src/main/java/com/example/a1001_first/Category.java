package com.example.a1001_first;

public enum Category {
    Food,Electricity,Restaurant,Vacation
}
