package com.example.a1001_first;

public interface CustomersDAO {
    
}
