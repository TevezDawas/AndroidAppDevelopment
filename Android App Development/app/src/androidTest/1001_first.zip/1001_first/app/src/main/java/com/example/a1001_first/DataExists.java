package com.example.a1001_first;

public class DataExists extends Exception{
    public DataExists(String message) {
        super(message);
    }
}
